package com.yupi.project.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yupi.project.model.entity.User;

/**
 * @Entity com.yupi.project.model.domain.User
 */
public interface UserMapper extends BaseMapper<User> {

}




