package com.yupi.springbootinit.wxmp;

/**
 * 微信公众号相关常量
 *  这个文件夹里都是，如果用户给你公众号进行发送信息，你可以用这些代码进行回复
 **/
public class WxMpConstant {

    /**
     * 点击菜单 key
     */
    public static final String CLICK_MENU_KEY = "CLICK_MENU_KEY";

}
